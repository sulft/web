Date : 
Créateur : Terry VILVER
but du projet : Projet d'une page statique d'un restaurant destiné a montré mes compétences de design.
technologies utilisés : Bootstrap, HTML5 et CSS3.
Directement utilisable en double cliquant sur le fichier HTML

